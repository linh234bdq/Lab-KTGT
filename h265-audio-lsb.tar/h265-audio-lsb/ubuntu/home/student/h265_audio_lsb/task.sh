#!/bin/bash

python3 embed_audio_lsb.py
python3 extract_audio_lsb.py
python3 merge_audio_video.py
python3 compare_audio.py

cat /home/student/result.txt
