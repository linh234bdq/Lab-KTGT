#!/usr/bin/env python3
import os
import wave
import numpy as np

OUTPUT_DIR = "output"
AUDIO_STEGO = os.path.join(OUTPUT_DIR, "audio_stego.wav")
EXTRACTED_SECRET = os.path.join(OUTPUT_DIR, "extracted_secret.txt")
RESULT_FILE = "/home/student/result.txt"

LSB_BIT = 0
END_MARKER = "1111111111111110"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def bits_to_text(bits):
    chars = []
    usable_length = len(bits) - (len(bits) % 8)

    for i in range(0, usable_length, 8):
        byte = bits[i:i+8]
        chars.append(int(byte, 2))

    return bytes(chars).decode("utf-8", errors="ignore")

def main():
    if not os.path.exists(AUDIO_STEGO):
        raise FileNotFoundError("Khong tim thay output/audio_stego.wav")

    with wave.open(AUDIO_STEGO, "rb") as wav:
        frames = wav.readframes(wav.getnframes())

    audio = np.frombuffer(frames, dtype=np.int16)

    bits = ""
    for sample in audio:
        bit = (sample >> LSB_BIT) & 1
        bits += str(bit)

        if bits.endswith(END_MARKER):
            bits = bits[:-len(END_MARKER)]
            break

    message = bits_to_text(bits)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    with open(EXTRACTED_SECRET, "w", encoding="utf-8") as f:
        f.write(message + "\n")

    if message:
        write_result("message_extracted")
        print("Thong diep trich xuat:", message)
    else:
        raise ValueError("Khong trich xuat duoc thong diep")

if __name__ == "__main__":
    main()
