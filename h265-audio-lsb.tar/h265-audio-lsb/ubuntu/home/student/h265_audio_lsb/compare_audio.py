#!/usr/bin/env python3
import os
import wave
import numpy as np

OUTPUT_DIR = "output"
AUDIO_ORIGINAL = os.path.join(OUTPUT_DIR, "audio_original.wav")
AUDIO_STEGO = os.path.join(OUTPUT_DIR, "audio_stego.wav")
REPORT = os.path.join(OUTPUT_DIR, "audio_compare_report.txt")

RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def read_wav_samples(path):
    with wave.open(path, "rb") as wav:
        frames = wav.readframes(wav.getnframes())
    return np.frombuffer(frames, dtype=np.int16)

def main():
    if not os.path.exists(AUDIO_ORIGINAL):
        raise FileNotFoundError("Khong tim thay output/audio_original.wav")

    if not os.path.exists(AUDIO_STEGO):
        raise FileNotFoundError("Khong tim thay output/audio_stego.wav")

    original = read_wav_samples(AUDIO_ORIGINAL)
    stego = read_wav_samples(AUDIO_STEGO)

    length = min(len(original), len(stego))
    original = original[:length]
    stego = stego[:length]

    diff = np.abs(original.astype(np.int32) - stego.astype(np.int32))
    changed_samples = int(np.count_nonzero(diff))
    average_difference = float(np.mean(diff))

    report_text = (
        f"Total samples compared: {length}\n"
        f"Changed samples: {changed_samples}\n"
        f"Average difference: {average_difference}\n"
    )

    with open(REPORT, "w", encoding="utf-8") as f:
        f.write(report_text)

    print(report_text)

    write_result("audio_compared")
    write_result("audio_lsb_lab_done")

if __name__ == "__main__":
    main()
