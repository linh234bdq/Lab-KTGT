#!/usr/bin/env python3
import os
import wave
import subprocess
import numpy as np

INPUT_VIDEO = "input.mp4"
SECRET_FILE = "secret.txt"
OUTPUT_DIR = "output"

AUDIO_ORIGINAL = os.path.join(OUTPUT_DIR, "audio_original.wav")
AUDIO_STEGO = os.path.join(OUTPUT_DIR, "audio_stego.wav")

RESULT_FILE = "/home/student/result.txt"

# TODO: Sinh vien can sua hai dong nay
LSB_BIT = -1
END_MARKER = ""

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def run_command(cmd):
    print("[RUN]", " ".join(cmd))
    subprocess.run(cmd, check=True)

def text_to_bits(text):
    data = text.encode("utf-8")
    bits = ""
    for byte in data:
        bits += format(byte, "08b")
    return bits

def embed_bits_into_audio(input_wav, output_wav, bits, lsb_bit):
    with wave.open(input_wav, "rb") as wav:
        params = wav.getparams()
        frames = wav.readframes(wav.getnframes())

    audio = np.frombuffer(frames, dtype=np.int16).copy()

    if len(bits) > len(audio):
        raise ValueError("Thong diep qua dai so voi dung luong audio")

    mask = ~(1 << lsb_bit)

    for i, bit in enumerate(bits):
        audio[i] = (audio[i] & mask) | (int(bit) << lsb_bit)

    with wave.open(output_wav, "wb") as wav:
        wav.setparams(params)
        wav.writeframes(audio.tobytes())

def main():
    if os.path.exists(RESULT_FILE):
        os.remove(RESULT_FILE)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if LSB_BIT != 0:
        raise ValueError("invalid_lsb_bit")

    if END_MARKER == "":
        raise ValueError("invalid_end_marker")

    if not os.path.exists(INPUT_VIDEO):
        raise FileNotFoundError("Khong tim thay input.mp4")

    if not os.path.exists(SECRET_FILE):
        raise FileNotFoundError("Khong tim thay secret.txt")

    run_command([
        "ffmpeg", "-y",
        "-i", INPUT_VIDEO,
        "-vn",
        "-acodec", "pcm_s16le",
        "-ar", "44100",
        "-ac", "1",
        AUDIO_ORIGINAL
    ])
    write_result("audio_extracted")

    with open(SECRET_FILE, "r", encoding="utf-8") as f:
        secret = f.read().strip()

    if not secret:
        raise ValueError("secret.txt dang rong")

    secret_bits = text_to_bits(secret)
    full_bits = secret_bits + END_MARKER
    write_result("secret_converted_to_bits")

    embed_bits_into_audio(AUDIO_ORIGINAL, AUDIO_STEGO, full_bits, LSB_BIT)
    write_result("message_embedded_lsb")

    print("Da tach audio:", AUDIO_ORIGINAL)
    print("Da tao audio stego:", AUDIO_STEGO)

if __name__ == "__main__":
    main()
