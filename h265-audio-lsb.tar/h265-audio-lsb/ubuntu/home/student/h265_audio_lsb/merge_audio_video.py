#!/usr/bin/env python3
import os
import subprocess

INPUT_VIDEO = "input.mp4"
OUTPUT_DIR = "output"

VIDEO_H265 = os.path.join(OUTPUT_DIR, "video_h265.mp4")
AUDIO_STEGO = os.path.join(OUTPUT_DIR, "audio_stego.wav")
STEGO_VIDEO = os.path.join(OUTPUT_DIR, "stego_audio_video.mp4")

RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def run_command(cmd):
    print("[RUN]", " ".join(cmd))
    subprocess.run(cmd, check=True)

def main():
    if not os.path.exists(INPUT_VIDEO):
        raise FileNotFoundError("Khong tim thay input.mp4")

    if not os.path.exists(AUDIO_STEGO):
        raise FileNotFoundError("Khong tim thay output/audio_stego.wav")

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    run_command([
        "ffmpeg", "-y",
        "-i", INPUT_VIDEO,
        "-an",
        "-c:v", "libx265",
        "-crf", "28",
        VIDEO_H265
    ])

    run_command([
        "ffmpeg", "-y",
        "-i", VIDEO_H265,
        "-i", AUDIO_STEGO,
        "-map", "0:v:0",
        "-map", "1:a:0",
        "-c:v", "copy",
        "-c:a", "aac",
        STEGO_VIDEO
    ])

    write_result("audio_video_merged")
    print("Da tao video stego:", STEGO_VIDEO)

if __name__ == "__main__":
    main()
