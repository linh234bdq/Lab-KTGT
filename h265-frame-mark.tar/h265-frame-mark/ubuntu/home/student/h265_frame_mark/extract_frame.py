#!/usr/bin/env python3
import os
import cv2
import numpy as np

OUTPUT_DIR = "output"
STEGO_VIDEO = os.path.join(OUTPUT_DIR, "marked_h265.mp4")
EXTRACTED_SECRET = os.path.join(OUTPUT_DIR, "extracted_secret.txt")
BIT_LENGTH_FILE = os.path.join(OUTPUT_DIR, "bit_length.txt")

RESULT_FILE = "/home/student/result.txt"

FRAME_STEP = 10
THRESHOLD = 25

MARK_X1, MARK_Y1 = 20, 20
MARK_X2, MARK_Y2 = 80, 80

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def bits_to_text(bits):
    chars = []
    usable_length = len(bits) - (len(bits) % 8)

    for i in range(0, usable_length, 8):
        byte = bits[i:i+8]
        chars.append(int(byte, 2))

    return bytes(chars).decode("utf-8", errors="ignore")

def main():
    if not os.path.exists(STEGO_VIDEO):
        raise FileNotFoundError("Khong tim thay output/marked_h265.mp4")

    if not os.path.exists(BIT_LENGTH_FILE):
        raise FileNotFoundError("Khong tim thay output/bit_length.txt")

    with open(BIT_LENGTH_FILE, "r", encoding="utf-8") as f:
        bit_length = int(f.read().strip())

    cap = cv2.VideoCapture(STEGO_VIDEO)
    if not cap.isOpened():
        raise ValueError("Khong mo duoc video stego")

    bits = ""

    for bit_index in range(bit_length):
        frame_index = bit_index * FRAME_STEP
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_index)
        ret, frame = cap.read()

        if not ret:
            break

        region = frame[MARK_Y1:MARK_Y2, MARK_X1:MARK_X2]
        brightness = float(np.mean(region))

        if brightness > 135 + THRESHOLD:
            bits += "1"
        else:
            bits += "0"

    cap.release()

    message = bits_to_text(bits)

    with open(EXTRACTED_SECRET, "w", encoding="utf-8") as f:
        f.write(message + "\n")

    if message:
        write_result("message_extracted")
        print("Thong diep trich xuat:", message)
    else:
        raise ValueError("Khong trich xuat duoc thong diep")

if __name__ == "__main__":
    main()
