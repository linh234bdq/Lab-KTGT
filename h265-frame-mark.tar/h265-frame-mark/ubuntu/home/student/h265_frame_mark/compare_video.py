#!/usr/bin/env python3
import os
import cv2
import numpy as np

INPUT_VIDEO = "input.mp4"
STEGO_VIDEO = "output/marked_h265.mp4"
REPORT = "output/video_compare_report.txt"

RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    if not os.path.exists(INPUT_VIDEO):
        raise FileNotFoundError("Khong tim thay input.mp4")

    if not os.path.exists(STEGO_VIDEO):
        raise FileNotFoundError("Khong tim thay output/marked_h265.mp4")

    cap1 = cv2.VideoCapture(INPUT_VIDEO)
    cap2 = cv2.VideoCapture(STEGO_VIDEO)

    total_frames = 0
    total_diff = 0.0

    while True:
        ret1, frame1 = cap1.read()
        ret2, frame2 = cap2.read()

        if not ret1 or not ret2:
            break

        if frame1.shape != frame2.shape:
            continue

        diff = np.mean(np.abs(frame1.astype(np.float32) - frame2.astype(np.float32)))
        total_diff += diff
        total_frames += 1

    cap1.release()
    cap2.release()

    if total_frames == 0:
        raise ValueError("Khong so sanh duoc frame nao")

    avg_diff = total_diff / total_frames

    report = (
        f"Total checked frames: {total_frames}\n"
        f"Average frame difference: {avg_diff}\n"
    )

    os.makedirs("output", exist_ok=True)
    with open(REPORT, "w", encoding="utf-8") as f:
        f.write(report)

    print(report)

    write_result("video_compared")
    write_result("frame_mark_lab_done")

if __name__ == "__main__":
    main()
