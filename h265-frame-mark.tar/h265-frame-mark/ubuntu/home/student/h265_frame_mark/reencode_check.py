#!/usr/bin/env python3
import os
import subprocess

OUTPUT_DIR = "output"
STEGO_VIDEO = os.path.join(OUTPUT_DIR, "marked_h265.mp4")
REENCODED_VIDEO = os.path.join(OUTPUT_DIR, "reencoded_marked.mp4")

RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    if not os.path.exists(STEGO_VIDEO):
        raise FileNotFoundError("Khong tim thay output/marked_h265.mp4")

    subprocess.run([
        "ffmpeg", "-y",
        "-i", STEGO_VIDEO,
        "-c:v", "libx265",
        "-crf", "32",
        REENCODED_VIDEO
    ], check=True)

    write_result("video_reencoded")
    print("Da re-encode video:", REENCODED_VIDEO)

if __name__ == "__main__":
    main()
