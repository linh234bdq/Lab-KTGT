#!/bin/bash

python3 embed_frame.py
python3 extract_frame.py
python3 reencode_check.py
python3 compare_video.py

cat /home/student/result.txt
