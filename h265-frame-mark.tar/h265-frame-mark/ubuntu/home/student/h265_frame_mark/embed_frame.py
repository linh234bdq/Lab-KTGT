#!/usr/bin/env python3
import os
import cv2
import subprocess

INPUT_VIDEO = "input.mp4"
SECRET_FILE = "secret.txt"
OUTPUT_DIR = "output"

RAW_VIDEO = os.path.join(OUTPUT_DIR, "marked_raw.mp4")
H265_VIDEO = os.path.join(OUTPUT_DIR, "marked_h265.mp4")

RESULT_FILE = "/home/student/result.txt"

FRAME_STEP = 0
BRIGHTNESS_DELTA = 0

MARK_X1, MARK_Y1 = 20, 20
MARK_X2, MARK_Y2 = 80, 80

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def run_command(cmd):
    print("[RUN]", " ".join(cmd))
    subprocess.run(cmd, check=True)

def text_to_bits(text):
    bits = ""
    for byte in text.encode("utf-8"):
        bits += format(byte, "08b")
    return bits

def main():
    if os.path.exists(RESULT_FILE):
        os.remove(RESULT_FILE)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if FRAME_STEP <= 0:
        raise ValueError("invalid_frame_step")

    if BRIGHTNESS_DELTA <= 0:
        raise ValueError("invalid_brightness_delta")

    if not os.path.exists(INPUT_VIDEO):
        raise FileNotFoundError("Khong tim thay input.mp4")

    if not os.path.exists(SECRET_FILE):
        raise FileNotFoundError("Khong tim thay secret.txt")

    with open(SECRET_FILE, "r", encoding="utf-8") as f:
        secret = f.read().strip()

    bits = text_to_bits(secret)
    bit_length = len(bits)

    write_result("secret_converted_to_bits")

    cap = cv2.VideoCapture(INPUT_VIDEO)
    if not cap.isOpened():
        raise ValueError("Khong mo duoc video dau vao")

    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    frames = []
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(frame)

    cap.release()

    if not frames:
        raise ValueError("Khong doc duoc frame nao")

    write_result("frames_loaded")

    required_frames = bit_length * FRAME_STEP
    if required_frames >= len(frames):
        raise ValueError("Video khong du frame de nhung thong diep")

    for bit_index, bit in enumerate(bits):
        frame_index = bit_index * FRAME_STEP
        frame = frames[frame_index]

        if bit == "1":
            region = frame[MARK_Y1:MARK_Y2, MARK_X1:MARK_X2]
            region = cv2.convertScaleAbs(region, alpha=1.0, beta=BRIGHTNESS_DELTA)
            frame[MARK_Y1:MARK_Y2, MARK_X1:MARK_X2] = region

        frames[frame_index] = frame

    write_result("frames_marked")

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(RAW_VIDEO, fourcc, fps, (width, height))

    for frame in frames:
        writer.write(frame)

    writer.release()

    run_command([
        "ffmpeg", "-y",
        "-i", RAW_VIDEO,
        "-c:v", "libx265",
        "-crf", "28",
        H265_VIDEO
    ])

    write_result("video_encoded_h265")

    with open(os.path.join(OUTPUT_DIR, "bit_length.txt"), "w", encoding="utf-8") as f:
        f.write(str(bit_length))

    print("Da tao video stego:", H265_VIDEO)

if __name__ == "__main__":
    main()
