#!/bin/bash

python3 generate_qr.py
python3 embed_qr.py
python3 extract_frame.py
python3 read_qr.py
python3 compare_crf.py

cat /home/student/result.txt
