#!/usr/bin/env python3
import os
import cv2

FRAME = "output/extracted_frame.png"
DECODED = "output/decoded_secret.txt"
RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    if not os.path.exists(FRAME):
        raise FileNotFoundError("Khong tim thay output/extracted_frame.png")

    img = cv2.imread(FRAME)
    detector = cv2.QRCodeDetector()
    data, points, _ = detector.detectAndDecode(img)

    if not data:
        raise ValueError("Khong doc duoc QR")

    with open(DECODED, "w", encoding="utf-8") as f:
        f.write(data + "\n")

    write_result("qr_decoded")
    print("Noi dung QR:", data)

if __name__ == "__main__":
    main()
