#!/usr/bin/env python3
import os
import cv2
import subprocess

INPUT_VIDEO = "input.mp4"
OUTPUT_DIR = "output"

QR_IMAGE = os.path.join(OUTPUT_DIR, "secret_qr.png")
RAW_VIDEO = os.path.join(OUTPUT_DIR, "qr_video_raw.mp4")
H265_VIDEO = os.path.join(OUTPUT_DIR, "qr_video_h265.mp4")

RESULT_FILE = "/home/student/result.txt"

QR_SIZE = 0
QR_POS_X = -1
QR_POS_Y = -1
CRF_VALUE = 0

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def run_command(cmd):
    print("[RUN]", " ".join(cmd))
    subprocess.run(cmd, check=True)

def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if QR_SIZE <= 0:
        raise ValueError("invalid_qr_size")

    if QR_POS_X < 0 or QR_POS_Y < 0:
        raise ValueError("invalid_qr_position")

    if CRF_VALUE <= 0:
        raise ValueError("invalid_crf_value")

    if not os.path.exists(INPUT_VIDEO):
        raise FileNotFoundError("Khong tim thay input.mp4")

    if not os.path.exists(QR_IMAGE):
        raise FileNotFoundError("Chua co output/secret_qr.png. Hay chay python3 generate_qr.py truoc")

    qr = cv2.imread(QR_IMAGE)
    qr = cv2.resize(qr, (QR_SIZE, QR_SIZE))

    cap = cv2.VideoCapture(INPUT_VIDEO)
    if not cap.isOpened():
        raise ValueError("Khong mo duoc input.mp4")

    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    if QR_POS_X + QR_SIZE > width or QR_POS_Y + QR_SIZE > height:
        raise ValueError("QR vuot ra ngoai kich thuoc frame")

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(RAW_VIDEO, fourcc, fps, (width, height))

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame[QR_POS_Y:QR_POS_Y+QR_SIZE, QR_POS_X:QR_POS_X+QR_SIZE] = qr
        writer.write(frame)

    cap.release()
    writer.release()

    write_result("qr_embedded")

    run_command([
        "ffmpeg", "-y",
        "-i", RAW_VIDEO,
        "-c:v", "libx265",
        "-crf", str(CRF_VALUE),
        H265_VIDEO
    ])

    write_result("video_encoded_h265")
    print("Da tao video QR H.265:", H265_VIDEO)

if __name__ == "__main__":
    main()
