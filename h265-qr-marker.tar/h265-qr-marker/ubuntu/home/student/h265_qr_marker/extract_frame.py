#!/usr/bin/env python3
import os
import cv2

VIDEO = "output/qr_video_h265.mp4"
OUTPUT_FRAME = "output/extracted_frame.png"
RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    if not os.path.exists(VIDEO):
        raise FileNotFoundError("Khong tim thay output/qr_video_h265.mp4")

    cap = cv2.VideoCapture(VIDEO)
    ret, frame = cap.read()
    cap.release()

    if not ret:
        raise ValueError("Khong tach duoc frame")

    cv2.imwrite(OUTPUT_FRAME, frame)
    write_result("frame_extracted")
    print("Da tach frame:", OUTPUT_FRAME)

if __name__ == "__main__":
    main()
