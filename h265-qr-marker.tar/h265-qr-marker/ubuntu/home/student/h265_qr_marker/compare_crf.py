#!/usr/bin/env python3
import os
import cv2
import subprocess

RAW_VIDEO = "output/qr_video_raw.mp4"
REPORT = "output/crf_report.txt"
RESULT_FILE = "/home/student/result.txt"

CRF_LIST = [24, 28, 32, 36]

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def decode_qr_from_video(video_path):
    cap = cv2.VideoCapture(video_path)
    ret, frame = cap.read()
    cap.release()

    if not ret:
        return ""

    detector = cv2.QRCodeDetector()
    data, points, _ = detector.detectAndDecode(frame)
    return data

def main():
    if not os.path.exists(RAW_VIDEO):
        raise FileNotFoundError("Khong tim thay output/qr_video_raw.mp4")

    lines = []

    for crf in CRF_LIST:
        out_video = f"output/qr_crf_{crf}.mp4"

        subprocess.run([
            "ffmpeg", "-y",
            "-i", RAW_VIDEO,
            "-c:v", "libx265",
            "-crf", str(crf),
            out_video
        ], check=True)

        data = decode_qr_from_video(out_video)

        if data:
            line = f"CRF {crf}: readable"
        else:
            line = f"CRF {crf}: not_readable"

        print(line)
        lines.append(line)

    with open(REPORT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    write_result("crf_test_done")
    write_result("qr_marker_lab_done")

if __name__ == "__main__":
    main()
