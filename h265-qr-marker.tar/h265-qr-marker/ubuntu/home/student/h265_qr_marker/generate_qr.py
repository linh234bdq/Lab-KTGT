#!/usr/bin/env python3
import os
import qrcode

SECRET_FILE = "secret.txt"
OUTPUT_DIR = "output"
QR_IMAGE = os.path.join(OUTPUT_DIR, "secret_qr.png")
RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if not os.path.exists(SECRET_FILE):
        raise FileNotFoundError("Khong tim thay secret.txt")

    with open(SECRET_FILE, "r", encoding="utf-8") as f:
        secret = f.read().strip()

    if not secret:
        raise ValueError("secret.txt dang rong")

    qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=2
    )
    qr.add_data(secret)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    img.save(QR_IMAGE)

    write_result("qr_generated")
    print("Da tao QR:", QR_IMAGE)

if __name__ == "__main__":
    main()
