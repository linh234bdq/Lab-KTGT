#!/usr/bin/env python3
import subprocess
import os

INPUT_STEGO = "output/stego_metadata.mp4"
REENCODED = "output/reencoded_stego.mp4"
RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    subprocess.run([
        "ffmpeg", "-y",
        "-i", INPUT_STEGO,
        "-c:v", "libx265",
        "-crf", "30",
        REENCODED
    ], check=True)

    write_result("reencoded_video")
    print("Đã re-encode video:", REENCODED)

if __name__ == "__main__":
    main()
