#!/usr/bin/env python3
import subprocess
import os

INPUT_VIDEO = "input.mp4"
SECRET_FILE = "secret.txt"
OUTPUT_DIR = "output"
H265_VIDEO = os.path.join(OUTPUT_DIR, "input_h265.mp4")
STEGO_VIDEO = os.path.join(OUTPUT_DIR, "stego_metadata.mp4")
RESULT_FILE = "/home/student/result.txt"

METADATA_FIELD = ""

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def run_command(cmd):
    print("[RUN]", " ".join(cmd))
    subprocess.run(cmd, check=True)

def main():
    if os.path.exists(RESULT_FILE):
        os.remove(RESULT_FILE)
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    write_result("python3 embed_metadata_py")

    if METADATA_FIELD == "":
        raise ValueError("invalid_metadata_field")

    with open(SECRET_FILE, "r", encoding="utf-8") as f:
        secret = f.read().strip()

    run_command([
        "ffmpeg", "-y",
        "-i", INPUT_VIDEO,
        "-c:v", "libx265",
        "-crf", "28",
        H265_VIDEO
    ])
    write_result("encoded_h265")

    run_command([
        "ffmpeg", "-y",
        "-i", H265_VIDEO,
        "-metadata", f"{METADATA_FIELD}={secret}",
        "-codec", "copy",
        STEGO_VIDEO
    ])
    write_result("metadata_embedded")

    run_command([
        "ffprobe",
        "-v", "error",
        "-show_entries", f"format_tags={METADATA_FIELD}",
        "-of", "default=noprint_wrappers=1",
        STEGO_VIDEO
    ])
    write_result("metadata_checked")
    write_result("metadata_lab_done")

if __name__ == "__main__":
    main()
