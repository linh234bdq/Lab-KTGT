#!/usr/bin/env python3
import subprocess
import os

STEGO_VIDEO = "output/stego_metadata.mp4"
OUTPUT_SECRET = "output/extracted_secret.txt"
RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    cmd = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format_tags=comment",
        "-of", "default=noprint_wrappers=1:nokey=1",
        STEGO_VIDEO
    ]

    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
    secret = result.stdout.strip()

    os.makedirs("output", exist_ok=True)

    with open(OUTPUT_SECRET, "w", encoding="utf-8") as f:
        f.write(secret + "\n")

    if secret:
        write_result("metadata_extracted")
        print("Thông điệp trích xuất:", secret)
    else:
        raise ValueError("Không trích xuất được metadata")

if __name__ == "__main__":
    main()
