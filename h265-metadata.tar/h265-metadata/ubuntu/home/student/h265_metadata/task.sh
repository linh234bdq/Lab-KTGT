#!/bin/bash

rm -rf output
rm -f result.txt

python3 embed_metadata.py
python3 extract_metadata.py
python3 reencode_check.py

cat result.txt
