#!/usr/bin/env python3
import os
import subprocess

INPUT_VIDEO = "input.mp4"
SECRET_FILE = "secret.txt"
OUTPUT_DIR = "output"

H265_VIDEO = os.path.join(OUTPUT_DIR, "input_h265.mp4")
SECRET_SRT = os.path.join(OUTPUT_DIR, "secret.srt")
STEGO_VIDEO = os.path.join(OUTPUT_DIR, "stego_subtitle.mp4")

RESULT_FILE = "/home/student/result.txt"

# TODO: Sinh viên cần sửa 2 dòng này
SUBTITLE_CODEC = ""
SUBTITLE_MODE = ""

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def run_command(cmd):
    print("[RUN]", " ".join(cmd))
    subprocess.run(cmd, check=True)

def create_secret_srt(secret):
    srt_content = f"""1
00:00:01,000 --> 00:00:04,000
{secret}
"""
    with open(SECRET_SRT, "w", encoding="utf-8") as f:
        f.write(srt_content)

def main():
    if os.path.exists(RESULT_FILE):
        os.remove(RESULT_FILE)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if SUBTITLE_CODEC == "":
        raise ValueError("invalid_subtitle_codec")

    if SUBTITLE_MODE == "":
        raise ValueError("invalid_subtitle_mode")

    if SUBTITLE_CODEC != "mov_text":
        raise ValueError("invalid_subtitle_codec")

    if SUBTITLE_MODE != "hidden":
        raise ValueError("invalid_subtitle_mode")

    if not os.path.exists(INPUT_VIDEO):
        raise FileNotFoundError("Không tìm thấy input.mp4")

    if not os.path.exists(SECRET_FILE):
        raise FileNotFoundError("Không tìm thấy secret.txt")

    with open(SECRET_FILE, "r", encoding="utf-8") as f:
        secret = f.read().strip()

    if not secret:
        raise ValueError("secret.txt đang rỗng")

    create_secret_srt(secret)
    write_result("created_secret_srt")

    run_command([
        "ffmpeg", "-y",
        "-i", INPUT_VIDEO,
        "-c:v", "libx265",
        "-crf", "28",
        "-an",
        H265_VIDEO
    ])
    write_result("encoded_h265")

    run_command([
        "ffmpeg", "-y",
        "-i", H265_VIDEO,
        "-i", SECRET_SRT,
        "-map", "0:v",
        "-map", "1:0",
        "-c:v", "copy",
        "-c:s", SUBTITLE_CODEC,
        "-metadata:s:s:0", "title=hidden_secret_subtitle",
        "-disposition:s:0", "0",
        STEGO_VIDEO
    ])
    write_result("subtitle_embedded")

    print("Đã tạo video stego:", STEGO_VIDEO)
    print("Đã tạo subtitle bí mật:", SECRET_SRT)

if __name__ == "__main__":
    main()
