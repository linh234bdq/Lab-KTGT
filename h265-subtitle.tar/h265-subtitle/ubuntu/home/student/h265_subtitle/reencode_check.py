#!/usr/bin/env python3
import os
import subprocess

STEGO_VIDEO = "output/stego_subtitle.mp4"
REENCODED_VIDEO = "output/reencoded_subtitle.mp4"
RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    if not os.path.exists(STEGO_VIDEO):
        raise FileNotFoundError("Không tìm thấy output/stego_subtitle.mp4")

    subprocess.run([
        "ffmpeg", "-y",
        "-i", STEGO_VIDEO,
        "-map", "0",
        "-c:v", "libx265",
        "-crf", "30",
        "-c:s", "mov_text",
        REENCODED_VIDEO
    ], check=True)

    write_result("reencoded_video")
    write_result("subtitle_lab_done")

    print("Đã re-encode video:", REENCODED_VIDEO)

if __name__ == "__main__":
    main()
