#!/usr/bin/env python3
import os
import subprocess

STEGO_VIDEO = "output/stego_subtitle.mp4"
RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    if not os.path.exists(STEGO_VIDEO):
        raise FileNotFoundError("Không tìm thấy output/stego_subtitle.mp4")

    cmd = [
        "ffprobe",
        "-v", "error",
        "-select_streams", "s",
        "-show_entries", "stream=index,codec_name,codec_type",
        "-of", "default=noprint_wrappers=1",
        STEGO_VIDEO
    ]

    result = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=True
    )

    print(result.stdout)

    if "codec_type=subtitle" in result.stdout and "codec_name=mov_text" in result.stdout:
        write_result("subtitle_stream_checked")
    else:
        raise ValueError("Không tìm thấy subtitle stream mov_text")

if __name__ == "__main__":
    main()
