#!/usr/bin/env python3
import os
import subprocess

STEGO_VIDEO = "output/stego_subtitle.mp4"
EXTRACTED_SRT = "output/extracted_secret.srt"
RESULT_FILE = "/home/student/result.txt"

def write_result(tag):
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(tag + "\n")

def main():
    if not os.path.exists(STEGO_VIDEO):
        raise FileNotFoundError("Không tìm thấy output/stego_subtitle.mp4")

    subprocess.run([
        "ffmpeg", "-y",
        "-i", STEGO_VIDEO,
        "-map", "0:s:0",
        EXTRACTED_SRT
    ], check=True)

    if not os.path.exists(EXTRACTED_SRT):
        raise FileNotFoundError("Không trích xuất được subtitle")

    with open(EXTRACTED_SRT, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    print(content)

    if content.strip():
        write_result("subtitle_extracted")
    else:
        raise ValueError("File subtitle trích xuất bị rỗng")

if __name__ == "__main__":
    main()
