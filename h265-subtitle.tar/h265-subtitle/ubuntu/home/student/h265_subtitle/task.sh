#!/bin/bash

python3 embed_subtitle.py
python3 check_stream.py
python3 extract_subtitle.py
python3 reencode_check.py

cat /home/student/result.txt
